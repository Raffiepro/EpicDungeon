Extra levels here:

https://raffiepro.github.io/EpicDungeon/

(There are not many)